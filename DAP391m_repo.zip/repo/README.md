# DAP391m

Code for the paper "Forecast-Driven Smart Charging: Linking Session Energy Analysis, Hourly Demand Forecasting and Peak Reduction on ACN-Data" (FPT University, DAP391m, Fall 2026).

- RQ1: factors of session energy (sites 1, 2, 19)
- RQ2: hourly demand forecasting (sites 1, 2; horizons 1 h and 24 h)
- RQ3: cap-based smart charging scheduler driven by the RQ2 forecasts

## Contents

`notebooks/` holds the notebooks without outputs:

| Notebook | Content |
|---|---|
| `linear-regression.ipynb` | RQ2 linear-regression forecaster |
| `xgboost.ipynb` | RQ2 XGBoost forecaster |
| `lightgbm.ipynb` | RQ2 LightGBM forecaster |
| `rq2-aggregate.ipynb` | RQ2 aggregation of results |
| `rq3-smart-charging.ipynb` | RQ3 smart charging simulation |

## Data

The ACN-Data sessions are not included. Download them from the ACN-Data portal (Lee, Li and Low, 2019) and set the input path inside each notebook.

## Split

Train to 31/10/2019, validation to 15/01/2020, test from 16/01/2020 to the end of the data.
